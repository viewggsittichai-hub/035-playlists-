// server.js
// ระบบจัดการ Playlist เพลง - จุดเริ่มต้นของแอปพลิเคชัน
require('dotenv').config();
require('express-async-errors'); // ให้ error ใน async route ถูกส่งไปที่ error handler แทนที่จะทำให้เซิร์ฟเวอร์ล่ม
const express = require('express');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const methodOverride = require('method-override');
const path = require('path');

const { attachUser } = require('./middleware/auth');
const { connect } = require('./config/db');
const { hue } = require('./utils/helpers');

const mainRoutes = require('./routes/main');
const authRoutes = require('./routes/auth');
const playlistRoutes = require('./routes/playlists');
const profileRoutes = require('./routes/profile');
const themeRoutes = require('./routes/theme');
const { attachTheme } = require('./routes/theme');
const adminRoutes = require('./routes/admin');

const app = express();
app.locals.hue = hue; // ใช้ใน views เพื่อกำหนดสีปกเพลย์ลิสต์

// ----- View engine -----
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ----- Middleware -----
app.use(express.urlencoded({ extended: true })); // อ่านข้อมูลจากฟอร์ม (HTTP Request body)
app.use(express.json());
app.use(cookieParser());
app.use(methodOverride('_method'));
app.use(express.static(path.join(__dirname, 'public')));

// ----- Session: เก็บสถานะผู้ใช้ที่ล็อกอิน -----
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'music-playlist-secret',
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      maxAge: 1000 * 60 * 60 * 24 // 1 วัน
    }
  })
);

app.use(attachUser);
app.use(attachTheme); // ธีมสีจาก Cookie

// ----- Routing -----
app.use('/', mainRoutes);
app.use('/', authRoutes);
app.use('/playlists', playlistRoutes);
app.use('/profile', profileRoutes);
app.use('/theme', themeRoutes);
app.use('/admin', adminRoutes);

// ----- 404 -----
app.use((req, res) => {
  res.status(404).render('error', { title: 'ไม่พบหน้านี้', message: 'ไม่พบหน้าที่คุณต้องการ (404)' });
});

// ----- Error handler -----
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).render('error', { title: 'เกิดข้อผิดพลาด', message: err.message || 'เกิดข้อผิดพลาดบางอย่างในระบบ' });
});

const PORT = process.env.PORT || 3000;

// เชื่อมต่อ MongoDB ให้สำเร็จก่อน แล้วค่อยเปิดเซิร์ฟเวอร์
connect()
  .then(() => {
    console.log('✅ เชื่อมต่อ MongoDB สำเร็จ');
    app.listen(PORT, () => {
      console.log(`🎵 Music Playlist App กำลังทำงานที่ http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error('❌ เชื่อมต่อ MongoDB ไม่สำเร็จ:', err.message);
    console.error('   ตรวจสอบว่าเปิด MongoDB แล้ว และ MONGO_URI ใน .env ถูกต้อง');
    process.exit(1);
  });
