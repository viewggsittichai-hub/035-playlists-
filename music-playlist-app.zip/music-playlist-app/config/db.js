// config/db.js
// การเชื่อมต่อฐานข้อมูล MongoDB ด้วย Mongoose
// หมายเหตุ: ใช้ 127.0.0.1 แทน localhost เพราะ Node.js บางเวอร์ชัน/Windows จะแปลง localhost เป็น IPv6 (::1)
// ซึ่ง MongoDB มักไม่ได้ฟังอยู่ ทำให้เชื่อมต่อไม่สำเร็จ
const mongoose = require('mongoose');

const uri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/music_playlist';

async function connect() {
  mongoose.set('strictQuery', true);
  await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
  return mongoose.connection;
}

module.exports = { connect, uri };
