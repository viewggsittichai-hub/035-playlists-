// routes/profile.js
// FR-11: แก้ไขข้อมูลโปรไฟล์ส่วนตัว (ชื่อ, รูปโปรไฟล์, รหัสผ่าน)
const express = require('express');
const path = require('path');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const { User } = require('../models');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '..', 'public', 'uploads', 'avatars')),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `avatar_${req.session.user.user_id}_${Date.now()}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 2 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = /image\/(jpeg|png|gif|webp)/.test(file.mimetype);
    cb(ok ? null : new Error('รองรับเฉพาะไฟล์รูปภาพเท่านั้น'), ok);
  }
});

router.get('/', requireAuth, async (req, res) => {
  const user = await User.findById(req.session.user.user_id).lean();
  res.render('profile', { title: 'โปรไฟล์ของฉัน', user, error: null, success: req.query.success === '1' });
});

router.post('/', requireAuth, upload.single('avatar'), async (req, res) => {
  const { full_name, new_password, confirm_password } = req.body;
  const userId = req.session.user.user_id;

  try {
    if (!full_name || !full_name.trim()) {
      const user = await User.findById(userId).lean();
      return res.render('profile', { title: 'โปรไฟล์ของฉัน', user, error: 'กรุณาระบุชื่อ-นามสกุล', success: false });
    }

    if (new_password) {
      if (new_password.length < 6) {
        const user = await User.findById(userId).lean();
        return res.render('profile', {
          title: 'โปรไฟล์ของฉัน', user, success: false,
          error: 'รหัสผ่านใหม่ต้องมีอย่างน้อย 6 ตัวอักษร'
        });
      }
      if (new_password !== confirm_password) {
        const user = await User.findById(userId).lean();
        return res.render('profile', {
          title: 'โปรไฟล์ของฉัน', user, success: false,
          error: 'ยืนยันรหัสผ่านใหม่ไม่ตรงกัน'
        });
      }
    }

    const update = { full_name: full_name.trim() };
    if (req.file) update.avatar = '/uploads/avatars/' + req.file.filename;
    if (new_password) update.password = await bcrypt.hash(new_password, 10);

    await User.updateOne({ _id: userId }, { $set: update });

    // อัปเดตข้อมูลใน Session ให้ตรงกับฐานข้อมูล
    req.session.user.full_name = full_name.trim();
    if (req.file) req.session.user.avatar = '/uploads/avatars/' + req.file.filename;

    res.redirect('/profile?success=1');
  } catch (err) {
    console.error(err);
    const user = await User.findById(userId).lean();
    res.render('profile', { title: 'โปรไฟล์ของฉัน', user, success: false, error: 'เกิดข้อผิดพลาด กรุณาลองใหม่' });
  }
});

module.exports = router;
