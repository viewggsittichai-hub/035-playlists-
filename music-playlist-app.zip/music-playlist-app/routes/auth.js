// routes/auth.js
// FR-03: สมัครสมาชิก / ล็อกอิน / ล็อกเอาต์ (จัดการสถานะด้วย Session)
const express = require('express');
const bcrypt = require('bcryptjs');
const { User } = require('../models');

const router = express.Router();

const registerView = (res, error, old) =>
  res.render('register', { title: 'สมัครสมาชิก', error, old: old || {} });

const loginView = (res, error, redirectTo, registered) =>
  res.render('login', { title: 'เข้าสู่ระบบ', error, registered: !!registered, redirectTo: redirectTo || '/' });

// ----- สมัครสมาชิก -----
router.get('/register', (req, res) => {
  if (req.session.user) return res.redirect('/');
  registerView(res, null);
});

router.post('/register', async (req, res) => {
  const { username, email, password, confirm_password, full_name } = req.body;

  if (!username || !email || !password || !full_name) {
    return registerView(res, 'กรุณากรอกข้อมูลให้ครบทุกช่อง', req.body);
  }
  if (password !== confirm_password) {
    return registerView(res, 'รหัสผ่านทั้งสองช่องไม่ตรงกัน', req.body);
  }
  if (password.length < 6) {
    return registerView(res, 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร', req.body);
  }

  const existing = await User.findOne({
    $or: [{ username: username.trim() }, { email: email.trim().toLowerCase() }]
  });
  if (existing) {
    return registerView(res, 'ชื่อผู้ใช้หรืออีเมลนี้ถูกใช้งานแล้ว', req.body);
  }

  try {
    const hash = await bcrypt.hash(password, 10);
    await User.create({ username, email, password: hash, full_name, role: 'member' });
    res.redirect('/login?registered=1');
  } catch (err) {
    if (err.code === 11000) {
      return registerView(res, 'ชื่อผู้ใช้หรืออีเมลนี้ถูกใช้งานแล้ว', req.body);
    }
    throw err;
  }
});

// ----- ล็อกอิน -----
router.get('/login', (req, res) => {
  if (req.session.user) return res.redirect('/');
  loginView(res, null, req.query.redirect, req.query.registered === '1');
});

router.post('/login', async (req, res) => {
  const { username, password, redirectTo } = req.body;

  const user = await User.findOne({
    $or: [{ username: (username || '').trim() }, { email: (username || '').trim().toLowerCase() }]
  });

  if (!user) return loginView(res, 'ไม่พบชื่อผู้ใช้นี้ในระบบ', redirectTo);
  if (user.status === 'suspended') {
    return loginView(res, 'บัญชีนี้ถูกระงับการใช้งาน กรุณาติดต่อผู้ดูแลระบบ', redirectTo);
  }
  if (!(await bcrypt.compare(password || '', user.password))) {
    return loginView(res, 'รหัสผ่านไม่ถูกต้อง', redirectTo);
  }

  // เก็บสถานะผู้ใช้ไว้ใน Session
  req.session.user = {
    user_id: user._id.toString(),
    username: user.username,
    full_name: user.full_name,
    role: user.role,
    avatar: user.avatar
  };

  // อนุญาตเฉพาะ path ภายในเว็บ (กัน open redirect)
  const safe = typeof redirectTo === 'string' && /^\/(?![\/\\])/.test(redirectTo) ? redirectTo : '/';
  res.redirect(safe);
});

// ----- ล็อกเอาต์ -----
router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('connect.sid');
    res.redirect('/login');
  });
});

module.exports = router;
