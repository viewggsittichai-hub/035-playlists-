// routes/playlists.js
// FR-04..FR-10: จัดการเพลย์ลิสต์ของสมาชิก, ไลก์/คอมเมนต์, เพลย์ลิสต์ของฉัน
const express = require('express');
const mongoose = require('mongoose');
const { Playlist, Song } = require('../models');
const { requireAuth } = require('../middleware/auth');
const { escapeRegex, decoratePlaylist } = require('../utils/helpers');

const router = express.Router();

const notFound = (res) =>
  res.status(404).render('error', { title: 'ไม่พบเพลย์ลิสต์', message: 'ไม่พบเพลย์ลิสต์ที่ต้องการ' });

// id ที่ไม่ใช่ ObjectId ที่ถูกต้อง -> 404
router.param('id', (req, res, next, id) => (mongoose.isValidObjectId(id) ? next() : notFound(res)));
router.param('songId', (req, res, next, id) => (mongoose.isValidObjectId(id) ? next() : notFound(res)));

// ----- Helper: ดึงเพลย์ลิสต์ที่ต้องเป็นเจ้าของเท่านั้น (admin ข้ามได้) -----
async function getOwnedPlaylist(req, res) {
  const playlist = await Playlist.findById(req.params.id);
  if (!playlist) {
    notFound(res);
    return null;
  }
  const me = req.session.user;
  if (playlist.user.toString() !== me.user_id && me.role !== 'admin') {
    res.status(403).render('error', { title: 'ไม่มีสิทธิ์', message: 'คุณไม่มีสิทธิ์แก้ไขเพลย์ลิสต์นี้' });
    return null;
  }
  return playlist;
}

// ----- FR-10: เพลย์ลิสต์ทั้งหมดของฉัน -----
router.get('/mine', requireAuth, async (req, res) => {
  const playlists = await Playlist.find({ user: req.session.user.user_id }).sort({ created_at: -1 }).lean();
  res.render('my_playlists', { title: 'เพลย์ลิสต์ของฉัน', playlists: playlists.map(decoratePlaylist) });
});

// ----- FR-04: สร้างเพลย์ลิสต์ -----
router.get('/new', requireAuth, (req, res) => {
  res.render('playlist_form', { title: 'สร้างเพลย์ลิสต์ใหม่', playlist: null, error: null });
});

router.post('/', requireAuth, async (req, res) => {
  const { playlist_name, is_public } = req.body;
  if (!playlist_name || !playlist_name.trim()) {
    return res.render('playlist_form', { title: 'สร้างเพลย์ลิสต์ใหม่', playlist: null, error: 'กรุณาระบุชื่อเพลย์ลิสต์' });
  }
  const playlist = await Playlist.create({
    user: req.session.user.user_id,
    playlist_name: playlist_name.trim(),
    is_public: !!is_public
  });
  res.redirect('/playlists/' + playlist._id);
});

// ----- FR-04 / FR-07: แก้ไขเพลย์ลิสต์ (ชื่อ, Public/Private) -----
router.get('/:id/edit', requireAuth, async (req, res) => {
  const playlist = await getOwnedPlaylist(req, res);
  if (!playlist) return;
  res.render('playlist_form', { title: 'แก้ไขเพลย์ลิสต์', playlist: playlist.toObject(), error: null });
});

router.post('/:id/edit', requireAuth, async (req, res) => {
  const playlist = await getOwnedPlaylist(req, res);
  if (!playlist) return;
  const { playlist_name, is_public } = req.body;
  if (!playlist_name || !playlist_name.trim()) {
    return res.render('playlist_form', { title: 'แก้ไขเพลย์ลิสต์', playlist: playlist.toObject(), error: 'กรุณาระบุชื่อเพลย์ลิสต์' });
  }
  playlist.playlist_name = playlist_name.trim();
  playlist.is_public = !!is_public;
  await playlist.save();
  res.redirect('/playlists/' + playlist._id);
});

// ----- FR-04: ลบเพลย์ลิสต์ -----
router.post('/:id/delete', requireAuth, async (req, res) => {
  const playlist = await getOwnedPlaylist(req, res);
  if (!playlist) return;
  await playlist.deleteOne();
  res.redirect('/playlists/mine');
});

// ----- FR-06: ค้นหาเพลงเพื่อเพิ่มลงเพลย์ลิสต์ -----
router.get('/:id/add-song', requireAuth, async (req, res) => {
  const playlist = await getOwnedPlaylist(req, res);
  if (!playlist) return;
  const q = (req.query.q || '').trim();
  let songs;
  if (q) {
    const re = new RegExp(escapeRegex(q), 'i');
    songs = await Song.find({ $or: [{ title: re }, { artist: re }, { album: re }, { genre: re }] })
      .sort({ title: 1 }).limit(50).lean();
  } else {
    // ไม่ได้ค้นหา: แสดงเพลงทั้งหมด (ไม่รวมเพลงที่อยู่ในเพลย์ลิสต์นี้แล้ว)
    const inList = playlist.songs.map((x) => x.song);
    songs = await Song.find({ _id: { $nin: inList } }).sort({ title: 1 }).limit(50).lean();
  }
  res.render('add_song', { title: 'เพิ่มเพลงลงเพลย์ลิสต์', playlist: playlist.toObject(), songs, q });
});

// ----- FR-05: เพิ่มเพลงลงเพลย์ลิสต์ -----
router.post('/:id/songs', requireAuth, async (req, res) => {
  const playlist = await getOwnedPlaylist(req, res);
  if (!playlist) return;
  const { song_id } = req.body;
  if (mongoose.isValidObjectId(song_id) && (await Song.exists({ _id: song_id }))) {
    // เพิ่มเฉพาะเมื่อเพลงนี้ยังไม่อยู่ในเพลย์ลิสต์
    const already = playlist.songs.some((x) => x.song.toString() === song_id);
    if (!already) {
      playlist.songs.push({ song: song_id });
      await playlist.save();
    }
  }
  res.redirect('/playlists/' + playlist._id);
});

// ----- FR-05: ลบเพลงออกจากเพลย์ลิสต์ -----
router.post('/:id/songs/:songId/remove', requireAuth, async (req, res) => {
  const playlist = await getOwnedPlaylist(req, res);
  if (!playlist) return;
  playlist.songs = playlist.songs.filter((x) => x.song.toString() !== req.params.songId);
  await playlist.save();
  res.redirect('/playlists/' + playlist._id);
});

// ----- FR-05: จัดเรียงลำดับเพลง (เลื่อนขึ้น/ลง) -----
router.post('/:id/songs/:songId/move', requireAuth, async (req, res) => {
  const playlist = await getOwnedPlaylist(req, res);
  if (!playlist) return;
  const idx = playlist.songs.findIndex((x) => x.song.toString() === req.params.songId);
  const swapWith = req.body.direction === 'up' ? idx - 1 : idx + 1;
  if (idx !== -1 && swapWith >= 0 && swapWith < playlist.songs.length) {
    const arr = playlist.songs.toObject();
    [arr[idx], arr[swapWith]] = [arr[swapWith], arr[idx]];
    playlist.songs = arr;
    await playlist.save();
  }
  res.redirect('/playlists/' + playlist._id);
});

// ----- FR-02 / FR-08 / FR-09: ดูรายละเอียดเพลย์ลิสต์ (Public ดูได้ทุกคน, Private เฉพาะเจ้าของ) -----
router.get('/:id', async (req, res) => {
  const playlist = await Playlist.findById(req.params.id)
    .populate('user', 'full_name username')
    .populate('songs.song')
    .populate('comments.user', 'full_name username')
    .lean();
  if (!playlist || !playlist.user) return notFound(res);

  const me = req.session.user;
  const isOwner = !!me && playlist.user._id.toString() === me.user_id;

  if (!playlist.is_public && !isOwner && (!me || me.role !== 'admin')) {
    return res.status(403).render('error', {
      title: 'เพลย์ลิสต์ส่วนตัว',
      message: 'เพลย์ลิสต์นี้ถูกตั้งค่าเป็นส่วนตัว คุณไม่มีสิทธิ์เข้าถึง'
    });
  }

  const songs = playlist.songs.filter((x) => x.song).map((x) => x.song);
  const likedByMe = !!me && playlist.likes.some((u) => u.toString() === me.user_id);
  const comments = playlist.comments
    .filter((c) => c.user)
    .map((c) => ({
      _id: c._id,
      full_name: c.user.full_name,
      username: c.user.username,
      comment_text: c.comment_text,
      created_at: c.created_at
    }));

  playlist.owner_name = playlist.user.full_name;

  res.render('playlist_view', {
    title: playlist.playlist_name,
    playlist,
    songs,
    isOwner,
    likeCount: playlist.likes.length,
    likedByMe,
    comments
  });
});

// ----- FR-08: กดไลก์ / ยกเลิกไลก์ เพลย์ลิสต์สาธารณะ -----
router.post('/:id/like', requireAuth, async (req, res) => {
  const playlist = await Playlist.findById(req.params.id);
  if (!playlist || !playlist.is_public) return res.redirect('/');
  const uid = req.session.user.user_id;
  const liked = playlist.likes.some((u) => u.toString() === uid);
  if (liked) {
    playlist.likes = playlist.likes.filter((u) => u.toString() !== uid);
  } else {
    playlist.likes.push(uid);
  }
  await playlist.save();
  res.redirect('/playlists/' + playlist._id);
});

// ----- FR-09: แสดงความคิดเห็นบนเพลย์ลิสต์สาธารณะ -----
router.post('/:id/comments', requireAuth, async (req, res) => {
  const playlist = await Playlist.findById(req.params.id);
  if (!playlist || !playlist.is_public) return res.redirect('/');
  const text = (req.body.comment_text || '').trim();
  if (text) {
    playlist.comments.push({ user: req.session.user.user_id, comment_text: text.slice(0, 500) });
    await playlist.save();
  }
  res.redirect('/playlists/' + playlist._id);
});

module.exports = router;
