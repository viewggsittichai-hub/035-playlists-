// routes/main.js
// FR-01: ค้นหาเพลย์ลิสต์สาธารณะและเพลง (สำหรับ Guest และทุกคน)
const express = require('express');
const { Song, Playlist } = require('../models');
const { escapeRegex, decoratePlaylist } = require('../utils/helpers');

const router = express.Router();

router.get('/', async (req, res) => {
  const q = (req.query.q || '').trim();
  let songs = [];
  let playlists = [];

  if (q) {
    const re = new RegExp(escapeRegex(q), 'i');
    songs = await Song.find({ $or: [{ title: re }, { artist: re }, { album: re }, { genre: re }] })
      .sort({ title: 1 }).limit(20).lean();
    playlists = await Playlist.find({ is_public: true, playlist_name: re })
      .populate('user', 'full_name').sort({ created_at: -1 }).limit(20).lean();
  } else {
    playlists = await Playlist.find({ is_public: true })
      .populate('user', 'full_name').sort({ created_at: -1 }).limit(12).lean();
  }

  res.render('index', { title: 'หน้าแรก', q, songs, playlists: playlists.map(decoratePlaylist) });
});

module.exports = router;
