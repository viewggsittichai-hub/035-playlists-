// routes/theme.js
// เลือกธีมสีของเว็บ — ใช้ได้ทุกคน (ผู้ใช้ทั่วไป, สมาชิก, แอดมิน)
// เก็บค่าธีมใน Cookie ชื่อ "theme" (อยู่ได้ 1 ปี) แล้วเซิร์ฟเวอร์ใส่ data-theme ให้ทุกหน้า
const express = require('express');

const THEMES = ['rose', 'violet', 'ocean', 'forest', 'dark'];
const DEFAULT_THEME = 'rose';

// Middleware: อ่านธีมจาก Cookie แล้วส่งให้ views ทุกหน้า
function attachTheme(req, res, next) {
  const t = req.cookies && req.cookies.theme;
  res.locals.theme = THEMES.includes(t) ? t : DEFAULT_THEME;
  // ใช้ย้อนกลับมาหน้าเดิมหลังเลือกธีม (เฉพาะหน้าที่เปิดด้วย GET)
  res.locals.currentUrl = req.method === 'GET' ? req.originalUrl : '/';
  next();
}

const router = express.Router();

router.post('/', (req, res) => {
  const { theme, back } = req.body;
  if (THEMES.includes(theme)) {
    res.cookie('theme', theme, {
      maxAge: 1000 * 60 * 60 * 24 * 365,
      sameSite: 'lax',
      path: '/'
    });
  }
  // ป้องกัน open redirect: อนุญาตเฉพาะ path ภายในเว็บ
  const safeBack = typeof back === 'string' && /^\/(?![\/\\])/.test(back) ? back : '/';
  res.redirect(safeBack);
});

module.exports = router;
module.exports.attachTheme = attachTheme;
module.exports.THEMES = THEMES;
