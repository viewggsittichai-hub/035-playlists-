// routes/admin.js
// FR-12..FR-15: จัดการข้อมูลเพลงหลัก, จัดการสมาชิก, ลบเนื้อหาไม่เหมาะสม, สถิติระบบ
const express = require('express');
const mongoose = require('mongoose');
const { User, Song, Playlist } = require('../models');
const { requireAdmin } = require('../middleware/auth');
const { decoratePlaylist } = require('../utils/helpers');

const router = express.Router();
router.use(requireAdmin);

// วนทุกเพลย์ลิสต์ แก้ไขด้วย fn(p) (คืนค่า true ถ้ามีการเปลี่ยนแปลง) แล้วบันทึก
async function updateAllPlaylists(fn) {
  const all = await Playlist.find();
  for (const p of all) {
    if (fn(p)) await p.save();
  }
}

// id ที่ไม่ถูกต้อง -> 404
router.param('id', (req, res, next, id) =>
  mongoose.isValidObjectId(id)
    ? next()
    : res.status(404).render('error', { title: 'ไม่พบข้อมูล', message: 'ไม่พบข้อมูลที่ต้องการ' })
);

// ----- FR-15: ภาพรวมสถิติระบบ -----
router.get('/', async (req, res) => {
  const [userCount, playlistCount, songCount] = await Promise.all([
    User.countDocuments({ role: 'member' }),
    Playlist.countDocuments(),
    Song.countDocuments()
  ]);

  const playlists = (await Playlist.find().populate('user', 'full_name').lean()).map(decoratePlaylist);

  // เพลย์ลิสต์ยอดนิยม: เรียงตามจำนวนไลก์
  const topPlaylists = [...playlists].sort((a, b) => b.like_count - a.like_count).slice(0, 5);

  // เพลงยอดนิยม: นับจากจำนวนครั้งที่เพลงถูกเพิ่มเข้าเพลย์ลิสต์ต่างๆ
  const counts = {};
  playlists.forEach((p) =>
    p.songs.forEach((x) => {
      if (x.song) counts[x.song.toString()] = (counts[x.song.toString()] || 0) + 1;
    })
  );
  const topIds = Object.keys(counts).sort((a, b) => counts[b] - counts[a]).slice(0, 5);
  const songDocs = await Song.find({ _id: { $in: topIds } }).lean();
  const topSongs = topIds
    .map((id) => {
      const s = songDocs.find((d) => d._id.toString() === id);
      return s ? { title: s.title, artist: s.artist, added_count: counts[id] } : null;
    })
    .filter(Boolean);

  res.render('admin/dashboard', {
    title: 'แดชบอร์ดผู้ดูแลระบบ',
    userCount, playlistCount, songCount, topPlaylists, topSongs
  });
});

// ===================== FR-12: จัดการข้อมูลเพลงหลัก =====================
router.get('/songs', async (req, res) => {
  const songs = await Song.find().sort({ created_at: -1 }).lean();
  res.render('admin/songs', { title: 'จัดการข้อมูลเพลง', songs });
});

router.get('/songs/new', (req, res) => {
  res.render('admin/song_form', { title: 'เพิ่มเพลงใหม่', song: null, error: null });
});

router.post('/songs', async (req, res) => {
  const { title, artist, album, genre } = req.body;
  if (!title || !title.trim() || !artist || !artist.trim()) {
    return res.render('admin/song_form', { title: 'เพิ่มเพลงใหม่', song: req.body, error: 'กรุณาระบุชื่อเพลงและศิลปิน' });
  }
  await Song.create({ title, artist, album, genre, created_by: req.session.user.user_id });
  res.redirect('/admin/songs');
});

router.get('/songs/:id/edit', async (req, res) => {
  const song = await Song.findById(req.params.id).lean();
  if (!song) return res.status(404).render('error', { title: 'ไม่พบเพลง', message: 'ไม่พบข้อมูลเพลงนี้' });
  res.render('admin/song_form', { title: 'แก้ไขข้อมูลเพลง', song, error: null });
});

router.post('/songs/:id/edit', async (req, res) => {
  const { title, artist, album, genre } = req.body;
  if (!title || !title.trim() || !artist || !artist.trim()) {
    return res.render('admin/song_form', {
      title: 'แก้ไขข้อมูลเพลง',
      song: { ...req.body, _id: req.params.id },
      error: 'กรุณาระบุชื่อเพลงและศิลปิน'
    });
  }
  await Song.updateOne(
    { _id: req.params.id },
    { $set: { title: title.trim(), artist: artist.trim(), album: (album || '').trim(), genre: (genre || '').trim() } }
  );
  res.redirect('/admin/songs');
});

router.post('/songs/:id/delete', async (req, res) => {
  await Song.deleteOne({ _id: req.params.id });
  // เอาเพลงนี้ออกจากทุกเพลย์ลิสต์ด้วย
  await updateAllPlaylists((p) => {
    const before = p.songs.length;
    p.songs = p.songs.filter((x) => x.song.toString() !== req.params.id);
    return p.songs.length !== before;
  });
  res.redirect('/admin/songs');
});

// ===================== FR-13: จัดการสมาชิก (ระงับ/ลบบัญชี) =====================
router.get('/users', async (req, res) => {
  const users = await User.find({ role: 'member' }).sort({ created_at: -1 }).lean();
  res.render('admin/users', { title: 'จัดการสมาชิก', users });
});

router.post('/users/:id/suspend', async (req, res) => {
  const user = await User.findOne({ _id: req.params.id, role: 'member' });
  if (user) {
    user.status = user.status === 'active' ? 'suspended' : 'active';
    await user.save();
  }
  res.redirect('/admin/users');
});

router.post('/users/:id/delete', async (req, res) => {
  const user = await User.findOne({ _id: req.params.id, role: 'member' });
  if (user) {
    await Playlist.deleteMany({ user: user._id });
    // เอาไลก์และคอมเมนต์ของสมาชิกคนนี้ออกจากเพลย์ลิสต์ของคนอื่น
    await updateAllPlaylists((p) => {
      const likes = p.likes.length;
      const comments = p.comments.length;
      p.likes = p.likes.filter((u) => u.toString() !== user._id.toString());
      p.comments = p.comments.filter((c) => c.user.toString() !== user._id.toString());
      return p.likes.length !== likes || p.comments.length !== comments;
    });
    await user.deleteOne();
  }
  res.redirect('/admin/users');
});

// ===================== FR-14: ลบเพลย์ลิสต์ / คอมเมนต์ที่ไม่เหมาะสม =====================
router.get('/playlists', async (req, res) => {
  const playlists = await Playlist.find().populate('user', 'full_name').sort({ created_at: -1 }).lean();
  res.render('admin/playlists', { title: 'จัดการเพลย์ลิสต์ทั้งหมด', playlists: playlists.map(decoratePlaylist) });
});

router.post('/playlists/:id/delete', async (req, res) => {
  await Playlist.deleteOne({ _id: req.params.id });
  res.redirect('/admin/playlists');
});

router.get('/comments', async (req, res) => {
  const playlists = await Playlist.find().populate('comments.user', 'full_name').lean();
  const comments = [];
  playlists.forEach((p) =>
    p.comments.forEach((c) =>
      comments.push({
        comment_id: c._id,
        comment_text: c.comment_text,
        full_name: c.user ? c.user.full_name : '-',
        playlist_name: p.playlist_name,
        playlist_id: p._id,
        created_at: c.created_at
      })
    )
  );
  comments.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  res.render('admin/comments', { title: 'จัดการความคิดเห็น', comments });
});

router.post('/comments/:id/delete', async (req, res) => {
  await updateAllPlaylists((p) => {
    const before = p.comments.length;
    p.comments = p.comments.filter((c) => c._id.toString() !== req.params.id);
    return p.comments.length !== before;
  });
  res.redirect('/admin/comments');
});

module.exports = router;
