// models/index.js
// โครงสร้างข้อมูล (Schema) ของระบบ — 3 collections: users, songs, playlists
// playlists เก็บเพลง/ไลก์/คอมเมนต์ไว้ในเอกสารเดียวกัน (embedded documents)
// ลำดับเพลงในเพลย์ลิสต์ = ลำดับของ array `songs`
const mongoose = require('mongoose');
const { Schema } = mongoose;

const userSchema = new Schema({
  username:   { type: String, required: true, unique: true, trim: true },
  email:      { type: String, required: true, unique: true, trim: true, lowercase: true },
  password:   { type: String, required: true }, // bcrypt hash
  full_name:  { type: String, required: true, trim: true },
  avatar:     { type: String, default: null },
  role:       { type: String, enum: ['admin', 'member'], default: 'member' },
  status:     { type: String, enum: ['active', 'suspended'], default: 'active' },
  created_at: { type: Date, default: Date.now }
});

// ข้อมูลเพลงหลัก (master data) จัดการโดย Admin — เก็บเฉพาะ metadata
const songSchema = new Schema({
  title:      { type: String, required: true, trim: true },
  artist:     { type: String, required: true, trim: true },
  album:      { type: String, default: '', trim: true },
  genre:      { type: String, default: '', trim: true },
  created_by: { type: Schema.Types.ObjectId, ref: 'User' },
  created_at: { type: Date, default: Date.now }
});

const playlistSchema = new Schema({
  user:          { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  playlist_name: { type: String, required: true, trim: true, maxlength: 100 },
  is_public:     { type: Boolean, default: false },
  songs: [{
    _id: false,
    song:     { type: Schema.Types.ObjectId, ref: 'Song' },
    added_at: { type: Date, default: Date.now }
  }],
  likes: [{ type: Schema.Types.ObjectId, ref: 'User' }],
  comments: [{
    user:         { type: Schema.Types.ObjectId, ref: 'User' },
    comment_text: { type: String, required: true, maxlength: 500 },
    created_at:   { type: Date, default: Date.now }
  }],
  created_at: { type: Date, default: Date.now }
});

module.exports = {
  User: mongoose.model('User', userSchema),
  Song: mongoose.model('Song', songSchema),
  Playlist: mongoose.model('Playlist', playlistSchema)
};
