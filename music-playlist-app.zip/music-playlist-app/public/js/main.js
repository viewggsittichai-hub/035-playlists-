// public/js/main.js
// ตัวอย่างการใช้ JavaScript ฝั่ง Client ร่วมกับ DOM Manipulation

document.addEventListener('DOMContentLoaded', function () {
  // 1) นับจำนวนตัวอักษรที่เหลือในกล่องคอมเมนต์แบบเรียลไทม์
  const commentBox = document.querySelector('.comment-form textarea');
  if (commentBox) {
    const counter = document.createElement('div');
    counter.className = 'muted';
    counter.style.fontSize = '0.8rem';
    counter.style.marginTop = '-10px';
    counter.style.marginBottom = '10px';
    const maxLen = parseInt(commentBox.getAttribute('maxlength') || '500', 10);
    const updateCounter = () => {
      counter.textContent = `${commentBox.value.length}/${maxLen} ตัวอักษร`;
    };
    commentBox.insertAdjacentElement('afterend', counter);
    updateCounter();
    commentBox.addEventListener('input', updateCounter);
  }

  // 2) ซ่อนข้อความแจ้งเตือน (alert) อัตโนมัติหลังจาก 4 วินาที
  document.querySelectorAll('.alert-success').forEach((el) => {
    setTimeout(() => {
      el.style.transition = 'opacity 0.5s ease';
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 500);
    }, 4000);
  });

  // 3) แสดงตัวอย่างรูปโปรไฟล์ก่อนอัปโหลดจริง (file input -> preview)
  const avatarInput = document.querySelector('input[name="avatar"]');
  const avatarPreview = document.querySelector('.profile-avatar img');
  if (avatarInput && avatarPreview) {
    avatarInput.addEventListener('change', function () {
      const file = this.files && this.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (e) => { avatarPreview.src = e.target.result; };
      reader.readAsDataURL(file);
    });
  }
});
