-- =====================================================================
-- ระบบจัดการ Playlist เพลง (Music Playlist Management System)
-- Engine: MySQL / MariaDB
-- ขอบเขต: เก็บเฉพาะ metadata ของเพลง (ชื่อเพลง/ศิลปิน/อัลบั้ม/แนวเพลง)
--         ไม่มีการเล่นไฟล์เสียงจริง ไม่เชื่อมต่อ API ภายนอก
-- Import:  mysql -u root -p < schema.sql
-- =====================================================================

CREATE DATABASE IF NOT EXISTS `playlist_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `playlist_db`;

SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- users : ผู้ใช้ทั่วไป(สมัครแล้ว)/สมาชิก/ผู้ดูแลระบบ
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id`    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username`   VARCHAR(50)  NOT NULL,
  `email`      VARCHAR(100) NOT NULL,
  `password`   VARCHAR(255) NOT NULL COMMENT 'bcrypt hash',
  `full_name`  VARCHAR(100) NOT NULL,
  `avatar`     VARCHAR(255) DEFAULT NULL,
  `role`       ENUM('admin','member') NOT NULL DEFAULT 'member',
  `status`     ENUM('active','suspended') NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uq_username` (`username`),
  UNIQUE KEY `uq_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- songs : ข้อมูลเพลงหลัก (master data) จัดการโดย Admin เท่านั้น
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `songs`;
CREATE TABLE `songs` (
  `song_id`     INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title`       VARCHAR(150) NOT NULL,
  `artist`      VARCHAR(100) NOT NULL,
  `album`       VARCHAR(150) DEFAULT NULL,
  `genre`       VARCHAR(50)  DEFAULT NULL,
  `created_by`  INT UNSIGNED NOT NULL,
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`song_id`),
  KEY `fk_song_user` (`created_by`),
  CONSTRAINT `fk_song_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- playlists : เพลย์ลิสต์ของสมาชิก (Public/Private)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `playlists`;
CREATE TABLE `playlists` (
  `playlist_id`   INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`       INT UNSIGNED NOT NULL,
  `playlist_name` VARCHAR(100) NOT NULL,
  `is_public`     TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`playlist_id`),
  KEY `fk_playlist_user` (`user_id`),
  CONSTRAINT `fk_playlist_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- playlist_songs : ตารางเชื่อม M:N playlists <-> songs (เก็บลำดับเพลง)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `playlist_songs`;
CREATE TABLE `playlist_songs` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `playlist_id` INT UNSIGNED NOT NULL,
  `song_id`     INT UNSIGNED NOT NULL,
  `position`    INT UNSIGNED NOT NULL DEFAULT 0,
  `added_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_playlist_song` (`playlist_id`,`song_id`),
  KEY `fk_ps_song` (`song_id`),
  CONSTRAINT `fk_ps_playlist` FOREIGN KEY (`playlist_id`) REFERENCES `playlists` (`playlist_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ps_song`     FOREIGN KEY (`song_id`)     REFERENCES `songs` (`song_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- playlist_likes : การกดไลก์เพลย์ลิสต์สาธารณะ
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `playlist_likes`;
CREATE TABLE `playlist_likes` (
  `playlist_id` INT UNSIGNED NOT NULL,
  `user_id`     INT UNSIGNED NOT NULL,
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`playlist_id`,`user_id`),
  CONSTRAINT `fk_like_playlist` FOREIGN KEY (`playlist_id`) REFERENCES `playlists` (`playlist_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_like_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- playlist_comments : คอมเมนต์บนเพลย์ลิสต์สาธารณะ
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `playlist_comments`;
CREATE TABLE `playlist_comments` (
  `comment_id`  INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `playlist_id` INT UNSIGNED NOT NULL,
  `user_id`     INT UNSIGNED NOT NULL,
  `comment_text` VARCHAR(500) NOT NULL,
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`comment_id`),
  KEY `fk_comment_playlist` (`playlist_id`),
  KEY `fk_comment_user` (`user_id`),
  CONSTRAINT `fk_comment_playlist` FOREIGN KEY (`playlist_id`) REFERENCES `playlists` (`playlist_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_comment_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
-- Sample data
-- Demo accounts (plain-text password to log in with, hashed below with bcrypt):
--   admin  : username "admin"   password "admin1234"
--   member : username "somchai" password "member1234" (all members share this demo password)
-- =====================================================================

-- NOTE: the bcrypt hashes below are generated once by running `node database/seed.js`
-- after `npm install`, which also inserts the sample songs/playlists for you.
-- This file only creates the schema; run `npm run seed` (see README) to load sample data.
