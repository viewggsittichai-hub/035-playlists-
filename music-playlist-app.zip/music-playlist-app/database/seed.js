// database/seed.js
// ล้างฐานข้อมูล MongoDB แล้วโหลดข้อมูลตัวอย่าง (ผู้ใช้, เพลง, เพลย์ลิสต์)
// วิธีใช้งาน:  npm run seed   (คำเตือน: ข้อมูลเดิมในฐานข้อมูลนี้จะถูกลบทั้งหมด)
require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const { connect, uri } = require('../config/db');
const { User, Song, Playlist } = require('../models');

async function seed() {
  console.log('⏳ กำลังเชื่อมต่อ MongoDB:', uri);
  await connect();
  await mongoose.connection.dropDatabase();
  await Promise.all([User.init(), Song.init(), Playlist.init()]); // สร้าง index (unique) ใหม่

  console.log('⏳ กำลังสร้างผู้ใช้ตัวอย่าง...');
  const adminHash = await bcrypt.hash('admin1234', 10);
  const memberHash = await bcrypt.hash('member1234', 10);
  const [admin, somchai, suda, nattapong] = await User.create([
    { username: 'admin', email: 'admin@musicapp.local', password: adminHash, full_name: 'ผู้ดูแลระบบ', role: 'admin' },
    { username: 'somchai', email: 'somchai@example.com', password: memberHash, full_name: 'สมชาย ใจดี' },
    { username: 'suda', email: 'suda@example.com', password: memberHash, full_name: 'สุดา แสนสุข' },
    { username: 'nattapong', email: 'nattapong@example.com', password: memberHash, full_name: 'ณัฐพงษ์ ดีมาก' }
  ]);

  console.log('⏳ กำลังเพิ่มเพลงตัวอย่าง...');
  const rows = [
    ['Sunset Glow', 'Sunset Boulevard', 'Sunset Dreams', 'Pop'],
    ['Dream Away', 'Sunset Boulevard', 'Sunset Dreams', 'Pop'],
    ['Jazz Rain', 'The Night Owls', 'Midnight Sessions', 'Jazz'],
    ['Cool Breeze', 'The Night Owls', 'Midnight Sessions', 'Jazz'],
    ['Silver Flow', 'MC Silver', 'Silver Tongue', 'Hip Hop'],
    ['Rhyme Time', 'MC Silver', 'Silver Tongue', 'Hip Hop'],
    ['Violin Whisper', 'Aurora Strings', 'String Serenade', 'Classical'],
    ['Pulse Drop', 'Neon Pulse', 'Digital Waves', 'Electronic'],
    ['Night Soul', 'River Soul', 'Soulful Nights', 'R&B'],
    ['Country Road', 'Golden Field', 'Golden Roads', 'Country']
  ];
  const songs = await Song.create(
    rows.map(([title, artist, album, genre]) => ({ title, artist, album, genre, created_by: admin._id }))
  );

  console.log('⏳ กำลังเพิ่ม Playlist ตัวอย่าง...');
  await Playlist.create([
    {
      user: somchai._id, playlist_name: 'เพลงโปรดของสมชาย', is_public: true,
      songs: [{ song: songs[0]._id }, { song: songs[2]._id }, { song: songs[4]._id }],
      likes: [suda._id, nattapong._id],
      comments: [{ user: suda._id, comment_text: 'เพลย์ลิสต์นี้เพราะมากเลยครับ!' }]
    },
    {
      user: suda._id, playlist_name: 'ฟังตอนอ่านหนังสือ', is_public: true,
      songs: [{ song: songs[6]._id }, { song: songs[3]._id }]
    },
    {
      user: somchai._id, playlist_name: 'ขับรถฟัง (ส่วนตัว)', is_public: false,
      songs: [{ song: songs[8]._id }]
    }
  ]);

  console.log('✅ เสร็จสิ้น! ข้อมูลตัวอย่างถูกเพิ่มเรียบร้อยแล้ว');
  console.log('   Admin  -> username: admin    password: admin1234');
  console.log('   Member -> username: somchai  password: member1234');
  await mongoose.disconnect();
}

seed().catch((err) => {
  console.error('❌ เกิดข้อผิดพลาด:', err.message);
  console.error('   ตรวจสอบว่าเปิด MongoDB แล้ว และ MONGO_URI ใน .env ถูกต้อง');
  process.exit(1);
});
