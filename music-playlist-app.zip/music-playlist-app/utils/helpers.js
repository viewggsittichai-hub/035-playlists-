// utils/helpers.js
// ฟังก์ชันช่วยเหลือที่ใช้ร่วมกันใน routes / views

// ป้องกันอักขระพิเศษของ RegExp เวลาใช้คำค้นหาของผู้ใช้
function escapeRegex(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// สีของปกเพลย์ลิสต์ (0-359) คำนวณจาก id ให้ได้สีเดิมทุกครั้ง
function hue(id) {
  let h = 0;
  for (const ch of String(id)) h = (h * 31 + ch.charCodeAt(0)) % 360;
  return h;
}

// เพิ่มฟิลด์สำหรับแสดงผล: ชื่อเจ้าของ, จำนวนไลก์, จำนวนเพลง
function decoratePlaylist(p) {
  return {
    ...p,
    owner_name: p.user && p.user.full_name ? p.user.full_name : '-',
    like_count: (p.likes || []).length,
    song_count: (p.songs || []).length
  };
}

module.exports = { escapeRegex, hue, decoratePlaylist };
