// middleware/auth.js
// ตรวจสอบสถานะการล็อกอินของผู้ใช้จาก Session

// ทำให้ req.session.user ใช้งานได้ใน views ทุกหน้า (res.locals)
function attachUser(req, res, next) {
  res.locals.currentUser = req.session.user || null;
  next();
}

// อนุญาตเฉพาะผู้ที่ล็อกอินแล้ว (สมาชิก/แอดมิน)
function requireAuth(req, res, next) {
  if (!req.session.user) {
    return res.redirect('/login?redirect=' + encodeURIComponent(req.originalUrl));
  }
  next();
}

// อนุญาตเฉพาะผู้ดูแลระบบ (Admin)
function requireAdmin(req, res, next) {
  if (!req.session.user) {
    return res.redirect('/login');
  }
  if (req.session.user.role !== 'admin') {
    return res.status(403).render('error', {
      title: 'ไม่มีสิทธิ์เข้าถึง',
      message: 'หน้านี้สำหรับผู้ดูแลระบบเท่านั้น'
    });
  }
  next();
}

module.exports = { attachUser, requireAuth, requireAdmin };
